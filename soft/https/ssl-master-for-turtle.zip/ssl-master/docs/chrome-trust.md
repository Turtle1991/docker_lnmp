# 如何让 Chrome 信任证书

1. 打开设置页面 `chrome://settings/certificates`，切换到 `授权中心`  
    ![](chrome-settings-certs.png)
1. 然后导入 `out/root.crt`  
    ![](chrome-settings-certs-imported.png)
1. 完成  
    ![](chrome-certs-ok.png)  
    ![](chrome-certs-details.png)

# How to contribute

If you would like to contribute, thank you :)

Here are a few informations you need to know before starting:

## Branches

Pull requests should be made against the master branch, which supports both PHP 7 and PHP 5.

## Testing

Tests are in phpt format in the tests directory. They can be run by executing `make test`.

void Bzero( void *s, size_t n); 

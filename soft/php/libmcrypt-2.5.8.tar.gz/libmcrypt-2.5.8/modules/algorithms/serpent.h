typedef struct {
      word32 l_key[140];
} SERPENT_KEY;


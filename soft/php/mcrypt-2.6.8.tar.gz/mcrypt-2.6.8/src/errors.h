void err_quit(char *errmsg);
void err_warn(char *errmsg);
void err_info(char *errmsg);
void err_crit(char *errmsg);

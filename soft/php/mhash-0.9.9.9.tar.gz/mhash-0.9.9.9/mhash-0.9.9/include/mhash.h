#if !defined(__MHASH_H)
#define __MHASH_H

#define MUTILS_USE_MHASH_CONFIG

#include <mutils/mincludes.h>
#include <mutils/mglobal.h>
#include <mutils/mtypes.h>
#include <mutils/mutils.h>
#include <mutils/mhash.h>

#endif

